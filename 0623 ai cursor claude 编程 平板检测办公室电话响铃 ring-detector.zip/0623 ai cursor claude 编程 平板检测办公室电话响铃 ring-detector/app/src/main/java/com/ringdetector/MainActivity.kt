package com.ringdetector

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var ntfyTopicInput: EditText
    private lateinit var modeSpinner: Spinner
    private lateinit var telegramTokenInput: EditText
    private lateinit var telegramChatInput: EditText
    private lateinit var telegramGroup: LinearLayout
    private lateinit var sensitivityBar: SeekBar
    private lateinit var sensitivityLabel: TextView
    private lateinit var testBtn: Button
    private lateinit var startBtn: Button
    private lateinit var stopBtn: Button
    private lateinit var statusText: TextView
    private lateinit var levelBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 绑定视图
        ntfyTopicInput = findViewById(R.id.ntfy_topic)
        modeSpinner = findViewById(R.id.notify_mode)
        telegramTokenInput = findViewById(R.id.telegraph_token)
        telegramChatInput = findViewById(R.id.telegraph_chat_id)
        telegramGroup = findViewById(R.id.telegraph_group)
        sensitivityBar = findViewById(R.id.sensitivity)
        sensitivityLabel = findViewById(R.id.sensitivity_label)
        testBtn = findViewById(R.id.btn_test)
        startBtn = findViewById(R.id.btn_start)
        stopBtn = findViewById(R.id.btn_stop)
        statusText = findViewById(R.id.status_text)
        levelBar = findViewById(R.id.level_bar)

        // 回调设置
        val prefs = getSharedPreferences("ring_detector", MODE_PRIVATE)
        ntfyTopicInput.setText(prefs.getString("ntfy_topic", "my-phone-ring"))
        val mode = prefs.getString("notification_mode", "ntfy")
        modeSpinner.setSelection(if (mode == "telegram") 1 else if (mode == "both") 2 else 0)
        telegramTokenInput.setText(prefs.getString("telegram_token", ""))
        telegramChatInput.setText(prefs.getString("telegram_chat_id", ""))
        sensitivityBar.progress = prefs.getInt("cooldown_seconds", 10)
        sensitivityLabel.text = "冷却间隔：${sensitivityBar.progress} 秒"
        updateTelegramVisibility()

        modeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                updateTelegramVisibility()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        sensitivityBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                sensitivityLabel.text = "冷却间隔：${progress.coerceAtLeast(1)} 秒"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        testBtn.setOnClickListener { sendTestNotification() }
        startBtn.setOnClickListener { startDetection() }
        stopBtn.setOnClickListener { stopDetection() }

        // 请求权限
        requestPermissions()
    }

    private fun updateTelegramVisibility() {
        val pos = modeSpinner.selectedItemPosition
        telegramGroup.visibility = if (pos == 1 || pos == 2) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun requestPermissions() {
        val missing = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) missing.add(Manifest.permission.RECORD_AUDIO)

        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) missing.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1)
        }
    }

    private fun saveSettings() {
        val prefs = getSharedPreferences("ring_detector", MODE_PRIVATE)
        prefs.edit()
            .putString("ntfy_topic", ntfyTopicInput.text.toString().trim())
            .putString("notification_mode", when (modeSpinner.selectedItemPosition) {
                1 -> "telegram"; 2 -> "both"; else -> "ntfy"
            })
            .putString("telegram_token", telegramTokenInput.text.toString().trim())
            .putString("telegram_chat_id", telegramChatInput.text.toString().trim())
            .putInt("cooldown_seconds", sensitivityBar.progress.coerceAtLeast(1))
            .apply()
    }

    private fun sendTestNotification() {
        saveSettings()
        val service = Intent(this, RingDetectService::class.java).apply {
            action = "START"
        }
        // 启动后立即模拟一次检测
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(service)
        } else {
            startService(service)
        }
        // 等待服务启动然后触发测试
        android.os.Handler(mainLooper).postDelayed({
            Toast.makeText(this, "测试通知已发送（查看 ntfy.sh/$ntfyTopicInput.text）", Toast.LENGTH_LONG).show()
        }, 2000)
    }

    private fun startDetection() {
        saveSettings()
        statusText.text = "状态：运行中"
        startBtn.isEnabled = false
        stopBtn.isEnabled = true

        val service = Intent(this, RingDetectService::class.java).apply {
            action = "START"
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(service)
        } else {
            startService(service)
        }
        Toast.makeText(this, "开始监听铃声...", Toast.LENGTH_SHORT).show()
    }

    private fun stopDetection() {
        statusText.text = "状态：已停止"
        startBtn.isEnabled = true
        stopBtn.isEnabled = false

        val service = Intent(this, RingDetectService::class.java).apply {
            action = "STOP"
        }
        stopService(service)
    }
}

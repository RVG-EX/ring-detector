package com.ringdetector

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.*
import kotlin.math.*

/**
 * 铃声检测引擎 — 实时监听麦克风，识别手机来电铃声特征
 *
 * 检测原理：
 *   1. 以 8000Hz 采样率录制环境音频
 *   2. 每 128ms（1024 采样）做一次 FFT
 *   3. 分析 800～4000Hz 频带能量（手机铃声主频区间）
 *   4. 检测"响→停→响→停"的周期性铃声模式
 */
class RingDetector(
    private val onRingDetected: () -> Unit,
    private val onLevelUpdate: (Float) -> Unit
) {
    companion object {
        const val SAMPLE_RATE = 8000
        private const val FFT_SIZE = 1024
        private const val CHUNK_MS = FFT_SIZE * 1000 / SAMPLE_RATE // 128ms

        // 频带范围
        private const val MIN_FREQ = 800f
        private const val MAX_FREQ = 4000f

        // 能量阈值（相对值，0~1）
        private const val ENERGY_THRESHOLD = 0.25f

        // 铃声模式：响约1~2秒，停约2~4秒
        private const val RING_ON_MIN_CHUNKS = 6    // ~0.8s
        private const val RING_ON_MAX_CHUNKS = 18   // ~2.3s
        private const val RING_OFF_MIN_CHUNKS = 12  // ~1.5s
        private const val RING_OFF_MAX_CHUNKS = 35  // ~4.5s

        // 至少检测到 N 个"响"周期才触发
        private const val MIN_RING_CYCLES = 2
    }

    private var audioRecord: AudioRecord? = null
    private var isRunning = false
    private var job: Job? = null

    // 模式识别状态
    private var ringCycleCount = 0
    private var consecutiveOnChunks = 0
    private var consecutiveOffChunks = 0
    private var patternState = 0 // 0=waiting, 1=ring_on, 2=ring_off

    // 自适应基线
    private var baselineEnergy = 0f
    private var baselineSamples = 0
    private var peakEnergy = 1f

    /**
     * 开始监听
     */
    fun start(scope: CoroutineScope) {
        if (isRunning) return
        isRunning = true

        val bufferSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(FFT_SIZE * 2)

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )

        audioRecord?.startRecording()

        // 先用前 2 秒采集环境基线
        baselineEnergy = 0f
        baselineSamples = 0
        peakEnergy = 1f

        job = scope.launch(Dispatchers.IO) {
            val buffer = ShortArray(FFT_SIZE)
            while (isActive && isRunning) {
                val read = audioRecord?.read(buffer, 0, FFT_SIZE) ?: -1
                if (read <= 0) continue

                // 转为浮点数组
                val samples = FloatArray(FFT_SIZE) { buffer[it].toFloat() / 32768f }

                // 汉宁窗
                for (i in samples.indices) {
                    samples[i] *= (0.5f - 0.5f * cos(2.0 * PI * i / (FFT_SIZE - 1))).toFloat()
                }

                // FFT
                val fft = FFT(FFT_SIZE)
                fft.forward(samples)

                // 各频带的幅度
                val magnitudes = FloatArray(FFT_SIZE / 2)
                for (i in 0 until FFT_SIZE / 2) {
                    magnitudes[i] = sqrt(
                        fft.real[i] * fft.real[i] + fft.imag[i] * fft.imag[i]
                    ).toFloat()
                }

                // 计算 800~4000Hz 频带能量
                val minBin = (MIN_FREQ * FFT_SIZE / SAMPLE_RATE).toInt().coerceAtLeast(1)
                val maxBin = (MAX_FREQ * FFT_SIZE / SAMPLE_RATE).toInt().coerceAtMost(FFT_SIZE / 2 - 1)
                var bandEnergy = 0f
                for (i in minBin..maxBin) {
                    bandEnergy += magnitudes[i] * magnitudes[i]
                }
                bandEnergy /= (maxBin - minBin + 1)
                bandEnergy = sqrt(bandEnergy)

                // 全频带能量（用于归一化）
                var totalEnergy = 0f
                for (i in 1 until FFT_SIZE / 2) {
                    totalEnergy += magnitudes[i] * magnitudes[i]
                }
                totalEnergy = sqrt(totalEnergy).coerceAtLeast(0.001f)

                // 归一化能量
                val normalizedEnergy = bandEnergy / totalEnergy

                // 更新自适应基线（前 ~2s）
                if (baselineSamples < 20) {
                    baselineEnergy += normalizedEnergy
                    baselineSamples++
                    if (baselineSamples == 20) {
                        baselineEnergy /= 20f
                        peakEnergy = max(baselineEnergy * 3f, 0.5f)
                        onLevelUpdate(0f)
                    }
                    continue
                }

                // 相对阈值
                val relativeEnergy = normalizedEnergy / peakEnergy.coerceAtLeast(0.01f)
                val displayLevel = relativeEnergy.coerceAtMost(1f)
                onLevelUpdate(displayLevel)

                val isLoud = relativeEnergy > ENERGY_THRESHOLD

                // 状态机：检测铃声的周期性 on/off 模式
                when (patternState) {
                    0 -> { // 等待铃声开始
                        if (isLoud) {
                            consecutiveOnChunks = 1
                            consecutiveOffChunks = 0
                            patternState = 1
                        }
                    }
                    1 -> { // 正在"响"
                        if (isLoud) {
                            consecutiveOnChunks++
                        } else {
                            // 响的阶段结束，检查长度
                            if (consecutiveOnChunks in RING_ON_MIN_CHUNKS..RING_ON_MAX_CHUNKS) {
                                consecutiveOffChunks = 1
                                patternState = 2
                                ringCycleCount++
                            } else {
                                // 太短或太长，不是铃声
                                resetPattern()
                            }
                        }
                    }
                    2 -> { // 正在"停"
                        if (isLoud) {
                            // 又开始响了
                            if (consecutiveOffChunks in RING_OFF_MIN_CHUNKS..RING_OFF_MAX_CHUNKS) {
                                // 合理间隔，开始下一个"响"周期
                                consecutiveOnChunks = 1
                                patternState = 1
                            } else {
                                // 间隔太长或太短，重置
                                resetPattern()
                            }
                        } else {
                            consecutiveOffChunks++
                            if (consecutiveOffChunks > RING_OFF_MAX_CHUNKS) {
                                // 停太久了
                                resetPattern()
                            }
                        }
                    }
                }

                // 检测到完整的 N 个 ring 周期
                if (ringCycleCount >= MIN_RING_CYCLES &&
                    patternState == 1 &&
                    consecutiveOnChunks >= RING_ON_MIN_CHUNKS / 2
                ) {
                    onRingDetected()
                    // 冷却期：重置，避免重复触发
                    resetPattern()
                    ringCycleCount = 0
                    delay(5000) // 5 秒冷却
                }
            }
        }
    }

    private fun resetPattern() {
        patternState = 0
        consecutiveOnChunks = 0
        consecutiveOffChunks = 0
        ringCycleCount = 0
    }

    fun stop() {
        isRunning = false
        job?.cancel()
        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null
    }
}

/**
 * 简单基-2 FFT（原地计算）
 */
class FFT(private val n: Int) {
    val real = FloatArray(n)
    val imag = FloatArray(n)

    // 预计算的旋转因子
    private val cosTable: FloatArray
    private val sinTable: FloatArray

    init {
        cosTable = FloatArray(n / 2)
        sinTable = FloatArray(n / 2)
        for (i in 0 until n / 2) {
            val angle = -2.0 * PI * i / n
            cosTable[i] = cos(angle).toFloat()
            sinTable[i] = sin(angle).toFloat()
        }
    }

    fun forward(input: FloatArray) {
        require(input.size == n)
        // 复制数据，位反转排序
        var j = 0
        for (i in 0 until n) {
            real[i] = input[i]
            imag[i] = 0f
        }
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = real[i]; real[i] = real[j]; real[j] = tr
                // imag 都是 0，不用交换
            }
        }

        // 蝶形计算
        var step = 1
        while (step < n) {
            val halfStep = step
            val tableStep = n / (step * 2)
            var pos = 0
            while (pos < n) {
                for (k in 0 until halfStep) {
                    val idx = k + pos
                    val idx2 = idx + halfStep
                    val tReal = real[idx2] * cosTable[k * tableStep] - imag[idx2] * sinTable[k * tableStep]
                    val tImag = real[idx2] * sinTable[k * tableStep] + imag[idx2] * cosTable[k * tableStep]
                    real[idx2] = real[idx] - tReal
                    imag[idx2] = imag[idx] - tImag
                    real[idx] += tReal
                    imag[idx] += tImag
                }
                pos += step * 2
            }
            step *= 2
        }
    }
}

package com.ringdetector

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class RingDetectService : Service() {

    private lateinit var detector: RingDetector
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val okHttp = OkHttpClient()
    private var wakeLock: PowerManager.WakeLock? = null

    // 可配置项
    private var ntfyTopic = ""
    private var telegramToken = ""
    private var telegramChatId = ""
    private var notificationMode = "ntfy" // "ntfy" | "telegram" | "both"
    private var lastAlertTime = 0L
    private var cooldownSeconds = 10

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        // 加载设置
        val prefs = getSharedPreferences("ring_detector", MODE_PRIVATE)
        ntfyTopic = prefs.getString("ntfy_topic", "my-phone-ring") ?: "my-phone-ring"
        telegramToken = prefs.getString("telegram_token", "") ?: ""
        telegramChatId = prefs.getString("telegram_chat_id", "") ?: ""
        notificationMode = prefs.getString("notification_mode", "ntfy") ?: "ntfy"
        cooldownSeconds = prefs.getInt("cooldown_seconds", 10)

        // 唤醒锁
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "RingDetector:WakeLock"
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "START" -> startDetection()
            "STOP" -> stopSelf()
        }
        return START_STICKY
    }

    private fun startDetection() {
        wakeLock?.acquire(10 * 60 * 1000L)

        val notification = buildNotification("监听中...", "麦克风正在检测手机铃声")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notification)
        }

        detector = RingDetector(
            onRingDetected = { onRing() },
            onLevelUpdate = { level -> updateNotificationLevel(level) }
        )
        detector.start(scope)
    }

    private fun onRing() {
        val now = System.currentTimeMillis()
        if (now - lastAlertTime < cooldownSeconds * 1000L) return
        lastAlertTime = now

        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val message = "🔔 检测到电话铃声！\n时间：$timeStr"

        // 发送通知
        when (notificationMode) {
            "ntfy" -> sendNtfy(message)
            "telegram" -> sendTelegram(message)
            "both" -> {
                sendNtfy(message)
                sendTelegram(message)
            }
        }

        // 更新前台通知
        val alertNotif = buildNotification("⚠️ 检测到铃声！", "已发送通知 ($timeStr)")
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(1, alertNotif)
    }

    private fun sendNtfy(message: String) {
        val json = """{"topic":"$ntfyTopic","title":"手机铃声提醒","message":"$message","priority":5}"""
        val body = json.toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url("https://ntfy.sh")
            .post(body)
            .build()
        okHttp.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }
            override fun onResponse(call: Call, response: Response) {
                response.close()
            }
        })
    }

    private fun sendTelegram(message: String) {
        if (telegramToken.isEmpty() || telegramChatId.isEmpty()) return
        val encoded = java.net.URLEncoder.encode(message, "UTF-8")
        val url = "https://api.telegram.org/bot$telegramToken/sendMessage?chat_id=$telegramChatId&text=$encoded"
        val request = Request.Builder().url(url).get().build()
        okHttp.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }
            override fun onResponse(call: Call, response: Response) {
                response.close()
            }
        })
    }

    private fun updateNotificationLevel(level: Float) {
        val db = (level * 100).toInt()
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(1, buildNotification("监听中... 音量:$db%", "麦克风工作正常"))
    }

    private fun buildNotification(title: String, text: String): Notification {
        val stopIntent = Intent(this, MainActivity::class.java).apply {
            action = "STOP"
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "铃声检测",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "麦克风监听状态"
        }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(channel)
    }

    override fun onDestroy() {
        if (::detector.isInitialized) detector.stop()
        scope.cancel()
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "ring_detect_channel"
    }
}
